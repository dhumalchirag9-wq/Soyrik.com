SOYRIK.COM WEBSITE STARTER

1. Open index.html in a browser to preview the responsive website.
2. In your GitHub repository, upload/replace index.html at the repository root.
3. To use your permanent couple photo in the homepage banner, rename the image to homepage-couple.jpg and upload it beside index.html.
4. Commit the changes. GitHub Pages should publish the static page.

IMPORTANT:
This is a polished FRONT-END starter. Search works on the sample cards and photo preview works in the browser.
Registration and login are demonstration forms only. They do NOT save accounts, authenticate users, or store member profiles.
Before collecting real member data, connect a secure backend/database, password authentication, admin moderation, privacy policy, consent, and abuse reporting. Never put passwords or private member data in this HTML file.
